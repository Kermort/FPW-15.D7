from django_filters import FilterSet
from .models import Post
 
 
class ProductFilter(FilterSet):
    class Meta:
        model = Post
        fields = {
            'create_time': ['gt'],  # мы хотим чтобы нам выводило имя хотя бы отдалённо похожее на то что запросил пользователь
            'title': ['icontains'],  # количество товаров должно быть больше или равно тому, что указал пользователь
            'author': ['exact'],  # цена должна быть меньше или равна тому, что указал пользователь
        }