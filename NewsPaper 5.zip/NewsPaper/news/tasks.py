from celery import shared_task
import time

@shared_task
def send_news():
    '''тут (будет) задача с рассылкой новостей каждый понедельник'''
    pass

@shared_task
def send_notification(uid):
    '''тут (будет) задача с отправкой пользователю уведомления после создания новости'''
    pass