from django.urls import path
from .views import ProductList, ProductDetail, Search, PostCreateView, PostDeleteView, PostUpdateView

urlpatterns = [
    path('', ProductList.as_view()),
    path('search/', Search.as_view()),
    path('<int:pk>/', ProductDetail.as_view(), name="news_detail"),
    path('create/', PostCreateView.as_view(), name="news_create"),
    path('create/<int:pk>', PostUpdateView.as_view(), name="news_update"),
    path('delete/<int:pk>', PostDeleteView.as_view(), name='news_delete'),
]